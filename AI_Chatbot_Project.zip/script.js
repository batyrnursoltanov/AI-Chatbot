const chat = document.getElementById("chat");
const form = document.getElementById("chatForm");
const input = document.getElementById("userInput");
const clearBtn = document.getElementById("clearBtn");

const knowledge = [
  {
    keys: ["html", "веб", "сайт"],
    answer: "HTML отвечает за структуру веб-страницы. CSS — за внешний вид, а JavaScript — за интерактивность."
  },
  {
    keys: ["javascript", "js"],
    answer: "JavaScript — язык программирования, который позволяет добавлять интерактивность и логику веб-страниц."
  },
  {
    keys: ["python", "питон"],
    answer: "Python часто используют для анализа данных, автоматизации и машинного обучения благодаря большому количеству библиотек."
  },
  {
    keys: ["ai", "ии", "искусственный интеллект"],
    answer: "Искусственный интеллект — область технологий, в которой компьютерные системы выполняют задачи, обычно требующие интеллектуальной обработки информации."
  },
  {
    keys: ["машинное обучение", "machine learning", "ml"],
    answer: "Машинное обучение позволяет модели находить закономерности в данных и использовать их для прогнозирования или классификации."
  },
  {
    keys: ["github"],
    answer: "GitHub — платформа для хранения кода, совместной разработки и публикации проектов с использованием Git."
  },
  {
    keys: ["спасибо", "благодарю"],
    answer: "Пожалуйста! Рад помочь 🙂"
  }
];

function normalize(text) {
  return text.toLowerCase().replace(/[.,!?;:()]/g, " ").replace(/\s+/g, " ").trim();
}

function getBotResponse(text) {
  const normalized = normalize(text);

  if (["привет", "здравствуйте", "добрый день", "hello", "hi"].some(x => normalized.includes(x))) {
    return "Привет! 👋 Чем могу помочь?";
  }

  if (normalized.includes("как дела")) {
    return "У меня всё отлично — готов отвечать на вопросы и демонстрировать работу чат-бота.";
  }

  for (const item of knowledge) {
    if (item.keys.some(key => normalized.includes(key))) {
      return item.answer;
    }
  }

  if (normalized.includes("что ты умеешь") || normalized.includes("помочь")) {
    return "Я могу отвечать на простые вопросы по AI, программированию, HTML, JavaScript, Python, GitHub и машинному обучению.";
  }

  return "Интересный вопрос! В этой демонстрационной версии я работаю на основе локальной базы знаний. Попробуй спросить про AI, Python, JavaScript, HTML, GitHub или машинное обучение.";
}

function addMessage(text, sender) {
  const row = document.createElement("div");
  row.className = `message ${sender}`;

  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = sender === "bot" ? "AI" : "YOU";

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;

  row.appendChild(avatar);
  row.appendChild(bubble);
  chat.appendChild(row);
  chat.scrollTop = chat.scrollHeight;
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  const text = input.value.trim();
  if (!text) return;

  addMessage(text, "user");
  input.value = "";

  setTimeout(() => addMessage(getBotResponse(text), "bot"), 450);
});

clearBtn.addEventListener("click", () => {
  chat.innerHTML = "";
  addMessage("История очищена. Чем могу помочь?", "bot");
  input.focus();
});
